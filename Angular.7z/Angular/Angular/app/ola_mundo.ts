﻿import {Component} from 'angular2/core';
@Component({
    selector: 'hello-world',
    templateUrl: 'app/ola_mundo.html'
})
export class HelloWorld
{
    yourName: string = '';
}