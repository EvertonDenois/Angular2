﻿import {bootstrap} from 'angular2/plataform/browser';
import {HelloWorld} from './ola_mundo';
bootstrap(HelloWrold);